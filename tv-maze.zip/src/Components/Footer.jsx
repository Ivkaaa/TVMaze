import React from "react";

class Footer extends React.Component{

    render(){
        return <div id="footer">
            <h3>Cerated by Bit Student 2022</h3>
        </div>
    }
}
export default Footer